const url = new URL(window.location.href);
const acc_event = url.searchParams.get("event");
const c_url = new URL(window.location.href);
c_url.searchParams.delete("event");
if (acc_event) {
  Swal.fire({
    title: "Account Deleted!",
    icon: "success",
    confirmButtonText: "OK",
  }).then(() => {
    window.location.replace(c_url);
  });
}
$("#loginForm").submit(async function (e) {
  e.preventDefault();
  const values = {
    value: document.getElementById("value").value,
    password: document.getElementById("password").value,
  }
  $.ajax({
    type: "POST",
    url: `/api/auth/login`,
    data: JSON.stringify(values),
  }).done(function (response) {
    if (response.message === "success") {
      window.location.href = "/";
    } else {
      return Swal.fire({
        title: "Error!",
        text: `Login was not successful! Error: ${response.message}`,
        icon: "error",
        confirmButtonText: "OK",
      });
    }
  });
});
$("#registerForm").submit(async function (e) {
  e.preventDefault();
  const email = document.getElementById("email").value;
  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;
  const data = {
    email: email,
    username: username,
    password: password
  };
  $.ajax({
    type: "POST",
    url: `/api/auth/register`,
    data: JSON.stringify(data),
  }).done(function (response) {
    if (response.message === "success") {
      window.location.href = "/";
    } else {
      return Swal.fire({
        title: "Error!",
        text: `Signup was not successful! Error: ${response.message}`,
        icon: "error",
        confirmButtonText: "OK",
      });
    }
  });
});