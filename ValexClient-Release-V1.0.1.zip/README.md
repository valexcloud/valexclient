# Valex Client V1.0.0

- Creation