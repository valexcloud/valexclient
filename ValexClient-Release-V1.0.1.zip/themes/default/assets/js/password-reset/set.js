const url = new URL(window.location.href);
const id = url.searchParams.get("id");
if (!id) {
  Swal.fire({
    title: "Error!",
    text: "Missing ID!",
    icon: "error",
    confirmButtonText: "OK",
  }).then(() => {
    window.location.replace("/password/reset");
  });
}
$.fn.serializeObject = function () {
  var o = {};
  var a = this.serializeArray();
  $.each(a, function () {
    if (o[this.name]) {
      if (!o[this.name].push) {
        o[this.name] = [o[this.name]];
      }
      o[this.name].push(this.value || "");
    } else {
      o[this.name] = this.value || "";
    }
  });
  const url = new URL(window.location.href);
  const id = url.searchParams.get("id");
  o.code = id;
  return o;
};
$("#resetForm").submit(async function (e) {
  e.preventDefault();
  const values = $(this).serializeObject();
  $.ajax({
    type: "POST",
    url: `/api/password/reset/set`,
    data: JSON.stringify(values),
  }).done(function (response) {
    if (response.message === "success") {
      return Swal.fire({
        title: "Success!",
        text: "Sign in with your new password!",
        icon: "success",
        confirmButtonText: "OK",
      }).then(() => {
        window.location.href = "/auth/login";
      });
    } else {
      return Swal.fire({
        title: "Error!",
        text: `${response.message}`,
        icon: "error",
        confirmButtonText: "OK",
      });
    }
  });
});
