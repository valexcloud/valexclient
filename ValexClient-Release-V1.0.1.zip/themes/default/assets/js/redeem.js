$.fn.serializeObject = function () {
  var o = {};
  var a = this.serializeArray();
  $.each(a, function () {
    if (o[this.name]) {
      if (!o[this.name].push) {
        o[this.name] = [o[this.name]];
      }
      o[this.name].push(this.value || "");
    } else {
      o[this.name] = this.value || "";
    }
  });
  return o;
};
$("#redeemCoupon").submit(async function (e) {
  e.preventDefault();
  const values = $(this).serializeObject();
  $.ajax({
    type: "POST",
    url: `/api/coupon/redeem`,
    data: JSON.stringify(values),
  }).done(function (response) {
    if (response.message === "success") {
      return Swal.fire({
        title: "Success!",
        text: "Redeemed Coupon!",
        icon: "success",
        confirmButtonText: "OK",
      });
    } else {
      return Swal.fire({
        title: "Error!",
        text: `${response.message}`,
        icon: "error",
        confirmButtonText: "OK",
      });
    }
  });
});
