function recaptchaSubmit(recaptchaResponse) {
  var data = {
    value: document.getElementById("value").value,
    password: document.getElementById("password").value,
    recaptchaResponse: recaptchaResponse,
  };
  $.ajax({
    type: "POST",
    url: `/api/recaptcha/login`,
    data: JSON.stringify(data),
  })
    .done(function (response) {
      dologin(response.value, response.password);
    })
    .fail(function (error) {
      return Swal.fire({
        title: "Error!",
        text: `ReCaptcha Error! Error: ${response.message}`,
        icon: "error",
        confirmButtonText: "OK",
      });
    })
    .always(function () {
      grecaptcha.reset();
    });
}
function dologin(value, password) {
  const values = {
    value: value,
    password: password,
  };
  $.ajax({
    type: "POST",
    url: `/api/auth/login`,
    data: JSON.stringify(values),
  }).done(function (response) {
    if (response.message === "success") {
      window.location.href = "/";
    } else {
      return Swal.fire({
        title: "Error!",
        text: `Login was not successful! Error: ${response.message}`,
        icon: "error",
        confirmButtonText: "OK",
      });
    }
  });
}
$("#loginForm").submit(async function (e) {
  e.preventDefault();
  grecaptcha.execute();
});
