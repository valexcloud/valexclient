$.fn.serializeObject = function () {
  var o = {};
  var a = this.serializeArray();
  $.each(a, function () {
    if (o[this.name]) {
      if (!o[this.name].push) {
        o[this.name] = [o[this.name]];
      }
      o[this.name].push(this.value || "");
    } else {
      o[this.name] = this.value || "";
    }
  });
  return o;
};
$("#add").submit(async function (e) {
  e.preventDefault();
  const values = $(this).serializeObject();
  $.ajax({
    type: "POST",
    url: `/api/join-for-rewards`,
    data: JSON.stringify(values),
  }).done(function (response) {
    if (response.message === "success") {
      return Swal.fire({
        title: "Success!",
        text: "Creating J4R Server was successful!",
        icon: "success",
        confirmButtonText: "OK",
      });
    } else {
      return Swal.fire({
        title: "Error!",
        text: `${response.message}`,
        icon: "error",
        confirmButtonText: "OK",
      });
    }
  });
});
$("#delete").submit(async function (e) {
  e.preventDefault();
  const values = $(this).serializeObject();
  $.ajax({
    type: "DELETE",
    url: `/api/join-for-rewards`,
    data: JSON.stringify(values),
  }).done(function (response) {
    if (response.message === "success") {
      return Swal.fire({
        title: "Success!",
        text: "Deleting J4R Server was successful!",
        icon: "success",
        confirmButtonText: "OK",
      });
    } else {
      return Swal.fire({
        title: "Error!",
        text: `${response.message}`,
        icon: "error",
        confirmButtonText: "OK",
      });
    }
  });
});
