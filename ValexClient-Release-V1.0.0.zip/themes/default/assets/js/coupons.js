$.fn.serializeObject = function () {
  var o = {};
  var a = this.serializeArray();
  $.each(a, function () {
    if (o[this.name]) {
      if (!o[this.name].push) {
        o[this.name] = [o[this.name]];
      }
      o[this.name].push(this.value || "");
    } else {
      o[this.name] = this.value || "";
    }
  });
  return o;
};
$("#create-coupon").submit(async function (e) {
  e.preventDefault();
  const values = $(this).serializeObject();
  $.ajax({
    type: "POST",
    url: `/api/coupon`,
    data: JSON.stringify(values),
  }).done(function (response) {
    if (response.message === "success") {
      return Swal.fire({
        title: "Success!",
        text: `Creating coupon ${response.code} was successful!`,
        icon: "success",
        confirmButtonText: "OK",
      }).then(() => (window.location.href = "/admin/coupons/list"));
    } else {
      return Swal.fire({
        title: "Error!",
        text: `${response.message}`,
        icon: "error",
        confirmButtonText: "OK",
      });
    }
  });
});
function deleteCoupon(code) {
  $.ajax({
    type: "DELETE",
    url: `/api/coupon/${code}`,
  }).done(function (response) {
    if (response.message === "success") {
      return Swal.fire({
        title: "Success!",
        text: `Deleting coupon ${response.code} was successful!`,
        icon: "success",
        confirmButtonText: "OK",
      }).then(() => (window.location.href = "/admin/coupons/list"));
    } else {
      return Swal.fire({
        title: "Error!",
        text: `${response.message}`,
        icon: "error",
        confirmButtonText: "OK",
      });
    }
  });
}
