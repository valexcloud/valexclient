$.fn.serializeObject = function () {
  var o = {};
  var a = this.serializeArray();
  $.each(a, function () {
    if (o[this.name]) {
      if (!o[this.name].push) {
        o[this.name] = [o[this.name]];
      }
      o[this.name].push(this.value || "");
    } else {
      o[this.name] = this.value || "";
    }
  });
  return o;
};
$("#create-package").submit(async function (e) {
  e.preventDefault();
  const values = $(this).serializeObject();
  $.ajax({
    type: "POST",
    url: `/api/package`,
    data: JSON.stringify(values),
  }).done(function (response) {
    if (response.message === "success") {
      return Swal.fire({
        title: "Success!",
        text: `Creating package ${response.name} was successful!`,
        icon: "success",
        confirmButtonText: "OK",
      }).then(() => (window.location.href = "/admin/packages/list"));
    } else {
      return Swal.fire({
        title: "Error!",
        text: `${response.message}`,
        icon: "error",
        confirmButtonText: "OK",
      });
    }
  });
});
$("#update-package").submit(async function (e) {
  e.preventDefault();
  const values = $(this).serializeObject();
  $.ajax({
    type: "PATCH",
    url: `/api/package`,
    data: JSON.stringify(values),
  }).done(function (response) {
    if (response.message === "success") {
      return Swal.fire({
        title: "Success!",
        text: `Editing package ${response.name} was successful!`,
        icon: "success",
        confirmButtonText: "OK",
      }).then(() => (window.location.href = "/admin/packages/list"));
    } else {
      return Swal.fire({
        title: "Error!",
        text: `${response.message}`,
        icon: "error",
        confirmButtonText: "OK",
      });
    }
  });
});
function deletePackage(name) {
  $.ajax({
    type: "DELETE",
    url: `/api/package`,
    data: JSON.stringify({
      name: name,
    }),
  }).done(function (response) {
    if (response.message === "success") {
      return Swal.fire({
        title: "Success!",
        text: `Deleting package ${response.name} was successful!`,
        icon: "success",
        confirmButtonText: "OK",
      }).then(() => (window.location.href = "/admin/packages/list"));
    } else {
      return Swal.fire({
        title: "Error!",
        text: `${response.message}`,
        icon: "error",
        confirmButtonText: "OK",
      });
    }
  });
}
