$(document).ready(() => {
    const url = new URL(window.location.href);
    const _event = url.searchParams.get("event");
    if (_event) {
      const event = base64Decode(_event);
      if (event == "account verified")
        return Swal.fire({
          title: "Success!",
          text: "Your account is now verified!",
          icon: "success",
          confirmButtonText: "OK",
        })
    }
})