$("#create-apikey").submit(async function (e) {
  e.preventDefault();
  const values = {
    memo: document.getElementById("memo").value,
    p_user: document.getElementById("p_user").value,
    p_resources: document.getElementById("p_resources").value,
    p_coupon: document.getElementById("p_coupon").value,
    p_leader: document.getElementById("p_leader").value,
    p_package: document.getElementById("p_package").value
  }
  $.ajax({
    type: "POST",
    url: `/api/apikeys`,
    data: JSON.stringify(values),
  }).done(function (response) {
    if (response.message === "success") {
      return Swal.fire({
        title: "Success!",
        text: `Creating API Key ${response.key} was successful!`,
        icon: "success",
        confirmButtonText: "OK",
      }).then(() => (window.location.href = "/admin/api-keys/list"));
    } else {
      return Swal.fire({
        title: "Error!",
        text: `${response.message}`,
        icon: "error",
        confirmButtonText: "OK",
      });
    }
  });
});
function delete_user(key) {
  $.ajax({
    type: "DELETE",
    url: `/api/apikeys/${key}`,
  }).done(function (response) {
    if (response.message == "success") {
      Swal.fire({
        title: "Success!",
        text: "The API Key have been deleted!",
        icon: "success",
        confirmButtonText: "OK",
      }).then(() => {
        location.reload();
      });
    } else {
      Swal.fire({
        title: "Error!",
        text: `Deleting API Key was not successful! Error: ${response.message}`,
        icon: "error",
        confirmButtonText: "OK",
      }).then(() => {
        location.reload();
      });
    }
  });
}