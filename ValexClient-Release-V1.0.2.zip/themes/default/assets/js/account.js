$("#change_password").submit(async function (e) {
  e.preventDefault();
  const password = document.getElementById("password").value;
  const confirm_password = document.getElementById("confirm_password").value;
  $.ajax({
    type: "POST",
    url: `/api/password/reset/set_int`,
    data: JSON.stringify({
      password: password,
      confirm_password: confirm_password,
    }),
  }).done(function (response) {
    if (response.message == "success") {
      Swal.fire({
        title: "Success!",
        text: "Your Password have been changed!",
        icon: "success",
        confirmButtonText: "OK",
      }).then(() => {
        location.reload();
      });
    } else {
      Swal.fire({
        title: "Error!",
        text: `${response.message}`,
        icon: "error",
        confirmButtonText: "OK",
      }).then(() => {
        location.reload();
      });
    }
  });
});
$("#change_panel_password").submit(async function (e) {
  e.preventDefault();
  const password = document.getElementById("panel_password").value;
  const confirm_password = document.getElementById(
    "panel_confirm_password"
  ).value;
  $.ajax({
    type: "POST",
    url: `/api/password/reset/set_panel`,
    data: JSON.stringify({
      password: password,
      confirm_password: confirm_password,
    }),
  }).done(function (response) {
    if (response.message == "success") {
      Swal.fire({
        title: "Success!",
        text: "Your Panel Password have been changed!",
        icon: "success",
        confirmButtonText: "OK",
      }).then(() => {
        location.reload();
      });
    } else {
      Swal.fire({
        title: "Error!",
        text: `${response.message}`,
        icon: "error",
        confirmButtonText: "OK",
      }).then(() => {
        location.reload();
      });
    }
  });
});
$("#change_email").submit(async function (e) {
  e.preventDefault();
  const email = document.getElementById("new_email").value;
  const password = document.getElementById("email_password").value;
  $.ajax({
    type: "PATCH",
    url: `/api/account/email`,
    data: JSON.stringify({
      email: email,
      password: password,
    }),
  }).done(function (response) {
    if (response.message == "success") {
      Swal.fire({
        title: "Success!",
        text: "Your Email have been changed!",
        icon: "success",
        confirmButtonText: "OK",
      }).then(() => {
        window.location.replace("/api/logout");
      });
    } else {
      Swal.fire({
        title: "Error!",
        text: `${response.message}`,
        icon: "error",
        confirmButtonText: "OK",
      }).then(() => {
        location.reload();
      });
    }
  });
});
$("#change_username").submit(async function (e) {
  e.preventDefault();
  const username = document.getElementById("new_username").value;
  const password = document.getElementById("username_password").value;
  $.ajax({
    type: "PATCH",
    url: `/api/account/username`,
    data: JSON.stringify({
      username: username,
      password: password,
    }),
  }).done(function (response) {
    if (response.message == "success") {
      Swal.fire({
        title: "Success!",
        text: "Your Username have been changed!",
        icon: "success",
        confirmButtonText: "OK",
      }).then(() => {
        location.reload();
      });
    } else {
      Swal.fire({
        title: "Error!",
        text: `${response.message}`,
        icon: "error",
        confirmButtonText: "OK",
      }).then(() => {
        location.reload();
      });
    }
  });
});
