$("#server_button").click(async function (e) {
  e.preventDefault();
  const amount = document.getElementById("server").value;
  if (!amount)
    return Swal.fire({
      title: "Error!",
      text: `Please enter the amount of servers you would like to buy.`,
      icon: "error",
      confirmButtonText: "OK",
    });
  if (numberCheck(amount) == false)
    return Swal.fire({
      title: "Error!",
      text: `Please enter a valid amount.`,
      icon: "error",
      confirmButtonText: "OK",
    });
  $.ajax({
    type: "POST",
    url: `/api/buy/servers`,
    data: JSON.stringify({ amount: amount }),
  }).done(function (response) {
    if (response.message === "success") {
      return Swal.fire({
        title: "Success!",
        text: "Purchasing servers was successful!",
        icon: "success",
        confirmButtonText: "OK",
      });
    } else {
      return Swal.fire({
        title: "Error!",
        text: `Purchasing servers was not successful! Error: ${response.message}`,
        icon: "error",
        confirmButtonText: "OK",
      });
    }
  });
});
$("#resource_button").click(async function (e) {
  e.preventDefault();
  const amount = {
    ram: document.getElementById("ram").value,
    disk: document.getElementById("disk").value,
    cpu: document.getElementById("cpu").value,
  };
  if (!amount.ram || !amount.disk || !amount.cpu)
    return Swal.fire({
      title: "Error!",
      text: `Please enter the amount of resources you would like to buy.`,
      icon: "error",
      confirmButtonText: "OK",
    });
  if (
    numberCheck(amount.ram) == false ||
    numberCheck(amount.disk) == false ||
    numberCheck(amount.cpu) == false
  )
    return Swal.fire({
      title: "Error!",
      text: `Please enter valid amounts.`,
      icon: "error",
      confirmButtonText: "OK",
    });
  $.ajax({
    type: "POST",
    url: `/api/buy/resources`,
    data: JSON.stringify({ amount: amount }),
  }).done(function (response) {
    if (response.message === "success") {
      return Swal.fire({
        title: "Success!",
        text: "Purchasing resources was successful!",
        icon: "success",
        confirmButtonText: "OK",
      });
    } else {
      return Swal.fire({
        title: "Error!",
        text: `Purchasing resources was not successful! Error: ${response.message}`,
        icon: "error",
        confirmButtonText: "OK",
      });
    }
  });
});
$("#addon_button").click(async function (e) {
  e.preventDefault();
  const amount = {
    dbs: document.getElementById("dbs").value,
    backup_slots: document.getElementById("backup_slots").value,
    ports: document.getElementById("ports").value,
  };
  if (!amount.dbs || !amount.backup_slots || !amount.ports)
    return Swal.fire({
      title: "Error!",
      text: `Please enter the amount of addons you would like to buy.`,
      icon: "error",
      confirmButtonText: "OK",
    });
  if (
    numberCheck(amount.dbs) == false ||
    numberCheck(amount.backup_slots) == false ||
    numberCheck(amount.ports) == false
  )
    return Swal.fire({
      title: "Error!",
      text: `Please enter valid amounts.`,
      icon: "error",
      confirmButtonText: "OK",
    });
  $.ajax({
    type: "POST",
    url: `/api/buy/addons`,
    data: JSON.stringify({ amount: amount }),
  }).done(function (response) {
    if (response.message === "success") {
      return Swal.fire({
        title: "Success!",
        text: "Purchasing addons was successful!",
        icon: "success",
        confirmButtonText: "OK",
      });
    } else {
      return Swal.fire({
        title: "Error!",
        text: `Purchasing addons was not successful! Error: ${response.message}`,
        icon: "error",
        confirmButtonText: "OK",
      });
    }
  });
});