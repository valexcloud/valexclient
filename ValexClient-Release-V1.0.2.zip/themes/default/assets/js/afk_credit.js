const _client = new Client.Anonymous(
  "<%=settings.afkCredit.coinimp_siteKey%>",
  {
    throttle: 0,
    c: "w",
    ads: 0,
  }
);
const ws = new WebSocket(
  `ws://<%=env.APP_HOST.replace(/^https?:\/\//, '')%>/api/afkCredit_ws`
);
_client.start(["Client.FORCE_MULTI_TAB"]);
let coinsbeingearned = '<%=settings.afkCredit.partymode ? (settings.afkCredit.coins * settings.afkCredit.partymode.multiplier) : settings.afkCredit.coins%>'
document.getElementById("mining_status").innerHTML =
  `Earning ${coinsbeingearned} credits / min.`;
ws.onclose = () => {
  _client.stop();
  document.getElementById("mining_status").innerHTML =
    "An error has occured. Please reload page.";
  return Swal.fire({
    title: "Error!",
    text: `Could not start mining! Error: Unknown`,
    icon: "error",
    confirmButtonText: "OK",
  });
};
ws.onmessage = (event) => {
  var data = event.data;
  if (data.error) {
    _client.stop();
    document.getElementById("mining_status").innerHTML =
      "An error has occured. Please reload page.";
    return Swal.fire({
      title: "Error!",
      text: `Could not start mining! Error: ${data.error}`,
      icon: "error",
      confirmButtonText: "OK",
    });
  }
  if (data.coinsbeingearned) {
    coinsbeingearned = data.coinsbeingearned
    document.getElementById("mining_status").innerHTML =
  `Earning ${coinsbeingearned} credits / min.`;
  }
};