$("#edit_user").submit(async function (e) {
  e.preventDefault();
  const url = new URL(window.location.href);
  const user_id = url.searchParams.get("user_id");
  const data = {
    email: document.getElementById("email").value,
    username: document.getElementById("username").value,
    package: document.getElementById("package").value,
    coins: document.getElementById("coins").value,
    verified: document.getElementById("verified").value,
    admin: document.getElementById("admin").value,
  };
  if (
    !data.email ||
    !data.username ||
    !data.package ||
    !data.coins ||
    !data.admin ||
    !data.verified
  )
    return Swal.fire({
      title: "Error!",
      text: `Please fillout the all of the fields!`,
      icon: "error",
      confirmButtonText: "OK",
    });
  $.ajax({
    type: "PATCH",
    url: `/api/user/${user_id}`,
    data: JSON.stringify(data),
  }).done(function (response) {
    if (response.message === "success") {
      return Swal.fire({
        title: "Success!",
        text: "Editing User was successful!",
        icon: "success",
        confirmButtonText: "OK",
      }).then(() => {
        window.location.replace("/admin/users/list");
      });
    } else {
      return Swal.fire({
        title: "Error!",
        text: `Editing User was not successful! Error: ${response.message}`,
        icon: "error",
        confirmButtonText: "OK",
      }).then(() => {
        window.location.replace("/admin/users/list");
      });
    }
  });
});
function delete_user(id) {
  $.ajax({
    type: "DELETE",
    url: `/api/user/${id}`,
  }).done(function (response) {
    if (response.message == "success") {
      Swal.fire({
        title: "Success!",
        text: "The user have been deleted!",
        icon: "success",
        confirmButtonText: "OK",
      }).then(() => {
        location.reload();
      });
    } else {
      Swal.fire({
        title: "Error!",
        text: `Deleting user was not successful! Error: ${response.message}`,
        icon: "error",
        confirmButtonText: "OK",
      }).then(() => {
        location.reload();
      });
    }
  });
}
function approve_user(id) {
  $.ajax({
    type: "POST",
    url: `/api/user/approve/${id}`,
  }).done(function (response) {
    if (response.message == "success") {
      Swal.fire({
        title: "Success!",
        text: "The user have been approved!",
        icon: "success",
        confirmButtonText: "OK",
      }).then(() => {
        location.reload();
      });
    } else {
      Swal.fire({
        title: "Error!",
        text: `Approving user was not successful! Error: ${response.message}`,
        icon: "error",
        confirmButtonText: "OK",
      }).then(() => {
        location.reload();
      });
    }
  });
}