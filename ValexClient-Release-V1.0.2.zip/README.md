# Valex Client V1.0.2

- Added Update Channels
- Boosted Page Loading Efficiency
- Added Update Instructions