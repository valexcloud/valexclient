function recaptchaSubmit(recaptchaResponse) {
  var data = {
    email: document.getElementById("email").value,
    username: document.getElementById("username").value,
    password: document.getElementById("password").value,
    recaptchaResponse: recaptchaResponse,
  };
  $.ajax({
    type: "POST",
    url: `/api/recaptcha/register`,
    data: JSON.stringify(data),
  })
    .done(function (response) {
      doregister(response.email, response.username, response.password);
    })
    .fail(function (error) {
      return Swal.fire({
        title: "Error!",
        text: `ReCaptcha Error! Error: ${response.message}`,
        icon: "error",
        confirmButtonText: "OK",
      });
    })
    .always(function () {
      grecaptcha.reset();
    });
}
function doregister(email, username, password) {
  const values = {
    email: email,
    username: username,
    password: password,
  };
  $.ajax({
    type: "POST",
    url: `/api/auth/register`,
    data: JSON.stringify(values),
  }).done(function (response) {
    if (response.message === "success") {
      window.location.href = "/";
    } else {
      return Swal.fire({
        title: "Error!",
        text: `Signup was not successful! Error: ${response.message}`,
        icon: "error",
        confirmButtonText: "OK",
      });
    }
  });
}
$("#registerForm").submit(async function (e) {
  e.preventDefault();
  grecaptcha.execute();
});
