$("#general").submit(async function (e) {
  e.preventDefault();
  const data = {
    update_channel: document.getElementById("update_channel").value,
    package: document.getElementById("default_package").value,
    requireApproval:
      document.getElementById("requireApproval").value === "true",
    favicon: document.getElementById("favicon_url").value,
    website_link: document.getElementById("website_link").value,
    privacy_policy_link: document.getElementById("privacy_policy_link").value,
    tos_link: document.getElementById("tos_link").value,
    tempmail_check: document.getElementById("tempmail_check").value === "true",
    recaptcha_sitekey: document.getElementById("sitekey").value,
    recaptcha_secretkey: document.getElementById("secretkey").value,
    recaptcha_enabled:
      document.getElementById("recaptcha_enable").value === "true",
  };
  $.ajax({
    type: "POST",
    url: `/api/websettings/general`,
    data: JSON.stringify(data),
  }).done(function (response) {
    if (response.message === "success") {
      return Swal.fire({
        title: "Success!",
        text: "Saving Settings was successful!",
        icon: "success",
        confirmButtonText: "OK",
      }).then(() => {
        location.reload();
      });
    } else {
      return Swal.fire({
        title: "Error!",
        text: `Saving Settings was not successful! Error: ${response.message}`,
        icon: "error",
        confirmButtonText: "OK",
      }).then(() => {
        location.reload();
      });
    }
  });
});
$("#discord").submit(async function (e) {
  e.preventDefault();
  const data = {
    invite: document.getElementById("discord_invite").value,
    enabled: document.getElementById("discord_enable").value === "true",
    oauth2_id: document.getElementById("discord_id").value,
    oauth2_secret: document.getElementById("discord_secret").value,
    bot_token: document.getElementById("discord_bot").value,
    j4r_enabled: document.getElementById("discord_j4r_enable").value === "true",
    guilds: document.getElementById("discord_guilds").value,
    registered_role: document.getElementById("discord_role").value,
  };
  $.ajax({
    type: "POST",
    url: `/api/websettings/discord`,
    data: JSON.stringify(data),
  }).done(function (response) {
    if (response.message === "success") {
      return Swal.fire({
        title: "Success!",
        text: "Saving Settings was successful!",
        icon: "success",
        confirmButtonText: "OK",
      }).then(() => {
        location.reload();
      });
    } else {
      return Swal.fire({
        title: "Error!",
        text: `Saving Settings was not successful! Error: ${response.message}`,
        icon: "error",
        confirmButtonText: "OK",
      }).then(() => {
        location.reload();
      });
    }
  });
});
$("#gateways").submit(async function (e) {
  e.preventDefault();
  const data = {
    enabled: document.getElementById("gateways_enable").value === "true",
    coins: Number(document.getElementById("coins").value),
    currency: document.getElementById("currency").value,
    paypal_enabled: document.getElementById("paypal_enable").value === "true",
    paypal_client_id: document.getElementById("paypal_clientid").value,
    paypal_client_secret: document.getElementById("paypal_clientsecret").value,
    stripe_enabled: document.getElementById("stripe_enable").value === "true",
    stripe_client_id: document.getElementById("stripe_clientid").value,
    stripe_client_secret: document.getElementById("stripe_clientsecret").value,
  };
  $.ajax({
    type: "POST",
    url: `/api/websettings/gateways`,
    data: JSON.stringify(data),
  }).done(function (response) {
    if (response.message === "success") {
      return Swal.fire({
        title: "Success!",
        text: "Saving Settings was successful!",
        icon: "success",
        confirmButtonText: "OK",
      }).then(() => {
        location.reload();
      });
    } else {
      return Swal.fire({
        title: "Error!",
        text: `Saving Settings was not successful! Error: ${response.message}`,
        icon: "error",
        confirmButtonText: "OK",
      }).then(() => {
        location.reload();
      });
    }
  });
});
$("#store").submit(async function (e) {
  e.preventDefault();
  const data = {
    coins_enabled: document.getElementById("coins_enable").value === "true",
    store_enabled: document.getElementById("store_enable").value === "true",
    server_cost: Number(document.getElementById("server_cost").value),
    cpu_cost: Number(document.getElementById("cpu_cost").value),
    cpu_per: Number(document.getElementById("cpu_amount").value),
    ram_cost: Number(document.getElementById("ram_cost").value),
    ram_per: Number(document.getElementById("ram_amount").value),
    disk_cost: Number(document.getElementById("disk_cost").value),
    disk_per: Number(document.getElementById("disk_amount").value),
    port_cost: Number(document.getElementById("port_cost").value),
    backup_cost: Number(document.getElementById("backup_cost").value),
    database_cost: Number(document.getElementById("database_cost").value),
    limit_enabled:
      document.getElementById("store_limits_enable").value === "true",
    server_limit: Number(document.getElementById("server_limit").value),
    cpu_limit: Number(document.getElementById("cpu_limit").value),
    ram_limit: Number(document.getElementById("ram_limit").value),
    disk_limit: Number(document.getElementById("disk_limit").value),
    port_limit: Number(document.getElementById("port_limit").value),
    backup_limit: Number(document.getElementById("backup_limit").value),
    database_limit: Number(document.getElementById("database_limit").value),
  };
  $.ajax({
    type: "POST",
    url: `/api/websettings/store`,
    data: JSON.stringify(data),
  }).done(function (response) {
    if (response.message === "success") {
      return Swal.fire({
        title: "Success!",
        text: "Saving Settings was successful!",
        icon: "success",
        confirmButtonText: "OK",
      }).then(() => {
        location.reload();
      });
    } else {
      return Swal.fire({
        title: "Error!",
        text: `Saving Settings was not successful! Error: ${response.message}`,
        icon: "error",
        confirmButtonText: "OK",
      }).then(() => {
        location.reload();
      });
    }
  });
});
$("#earning").submit(async function (e) {
  e.preventDefault();
  const data = {
    google_ads_enabled:
      document.getElementById("google_ads_enabled").value === "true",
    google_ads_client_id: document.getElementById("google_ads_client_id").value,
    gift_enabled: document.getElementById("gift_enable").value === "true",
    casino_enabled: document.getElementById("casino_enable").value === "true",
    casino_limit: Number(document.getElementById("casino_limit").value),
    linkvertise_enabled:
      document.getElementById("linkvertise_enable").value === "true",
    linkvertise_id: Number(document.getElementById("linkvertise_key").value),
    linkvertise_coins: Number(
      document.getElementById("linkvertise_coins").value
    ),
    referrals_enabled:
      document.getElementById("referrals_enable").value === "true",
    referrals_coins: Number(document.getElementById("referrals_coins").value),
    referrals_limit: document.getElementById("referrals_limit").value,
  };
  $.ajax({
    type: "POST",
    url: `/api/websettings/earning`,
    data: JSON.stringify(data),
  }).done(function (response) {
    if (response.message === "success") {
      return Swal.fire({
        title: "Success!",
        text: "Saving Settings was successful!",
        icon: "success",
        confirmButtonText: "OK",
      }).then(() => {
        location.reload();
      });
    } else {
      return Swal.fire({
        title: "Error!",
        text: `Saving Settings was not successful! Error: ${response.message}`,
        icon: "error",
        confirmButtonText: "OK",
      }).then(() => {
        location.reload();
      });
    }
  });
});
$("#login").submit(async function (e) {
  e.preventDefault();
  const data = {
    google_enabled: document.getElementById("google_enable").value === "true",
    google_client_id: document.getElementById("google_clientid").value,
    google_client_secret: document.getElementById("google_clientsecret").value,
    microsoft_enabled:
      document.getElementById("microsoft_enable").value === "true",
    microsoft_client_id: document.getElementById("microsoft_clientid").value,
    microsoft_client_secret: document.getElementById("microsoft_clientsecret")
      .value,
  };
  $.ajax({
    type: "POST",
    url: `/api/websettings/login`,
    data: JSON.stringify(data),
  }).done(function (response) {
    if (response.message === "success") {
      return Swal.fire({
        title: "Success!",
        text: "Saving Settings was successful!",
        icon: "success",
        confirmButtonText: "OK",
      }).then(() => {
        location.reload();
      });
    } else {
      return Swal.fire({
        title: "Error!",
        text: `Saving Settings was not successful! Error: ${response.message}`,
        icon: "error",
        confirmButtonText: "OK",
      }).then(() => {
        location.reload();
      });
    }
  });
});
