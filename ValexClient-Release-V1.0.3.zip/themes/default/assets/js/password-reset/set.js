const url = new URL(window.location.href);
const id = url.searchParams.get("id");
if (!id) {
  Swal.fire({
    title: "Error!",
    text: "Missing ID!",
    icon: "error",
    confirmButtonText: "OK",
  }).then(() => {
    window.location.replace("/password/reset");
  });
}
$("#resetForm").submit(async function (e) {
  e.preventDefault();
  const values = $(this).serializeObject();
  $.ajax({
    type: "POST",
    url: `/api/password/reset/set`,
    data: JSON.stringify(values),
  }).done(function (response) {
    if (response.message === "success") {
      return Swal.fire({
        title: "Success!",
        text: "Sign in with your new password!",
        icon: "success",
        confirmButtonText: "OK",
      }).then(() => {
        window.location.href = "/auth/login";
      });
    } else {
      return Swal.fire({
        title: "Error!",
        text: `${response.message}`,
        icon: "error",
        confirmButtonText: "OK",
      });
    }
  });
});
