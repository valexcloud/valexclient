Valex Client V1.0.5
- Removed Version Check on Startup

Valex Client V1.0.4

- Removed AFK System
- Fixed Logging System

Valex Client V1.0.3

- Restyled Change Log and Update Sections
- Fixed JS Bug

Valex Client V1.0.2

- Added Update Channels
- Boosted Page Loading Efficiency
- Added Update Instructions

Valex Client V1.0.1

- Fixed Reset Password
- Fixed Recaptcha
- Fixed Icons
- Fixed Settings resetting on restart

Valex Client V1.0.0

- Creation