$("#create_server").submit(async function (e) {
  e.preventDefault();
  const data = {
    name: document.getElementById("server_name").value,
    location: document.getElementById("server_location").value,
    application: document.getElementById("server_egg").value,
    cpu: document.getElementById("server_cpu").value,
    ram: document.getElementById("server_ram").value,
    disk: document.getElementById("server_disk").value,
    databases: document.getElementById("server_databases").value,
    backups: document.getElementById("server_backups").value,
    ports: document.getElementById("server_ports").value,
  };
  if (
    !data.name ||
    !data.location ||
    !data.application ||
    !data.cpu ||
    !data.ram ||
    !data.disk ||
    !data.databases ||
    !data.backups ||
    !data.ports
  )
    return Swal.fire({
      title: "Error!",
      text: `Please fillout the all of the fields!`,
      icon: "error",
      confirmButtonText: "OK",
    });
  if (
    numberCheck(data.cpu) == false ||
    numberCheck(data.ram) == false ||
    numberCheck(data.disk) == false ||
    numberCheck(data.databases) == false ||
    numberCheck(data.backups) == false ||
    numberCheck(data.ports) == false
  )
    return Swal.fire({
      title: "Error!",
      text: `Please enter valid information.`,
      icon: "error",
      confirmButtonText: "OK",
    });
  $.ajax({
    type: "POST",
    url: `/api/server`,
    data: JSON.stringify(data),
  }).done(function (response) {
    if (response.message === "success") {
      return Swal.fire({
        title: "Success!",
        text: "Creating Server was successful!",
        icon: "success",
        confirmButtonText: "OK",
      }).then(() => {
        window.location.replace("/");
      });
    } else {
      return Swal.fire({
        title: "Error!",
        text: `Creating Server was not successful! Error: ${response.message}`,
        icon: "error",
        confirmButtonText: "OK",
      }).then(() => {
        window.location.replace("/");
      });
    }
  });
});
$("#edit_server").submit(async function (e) {
  e.preventDefault();
  const url = new URL(window.location.href);
  const server_id = url.searchParams.get("server_id");
  const data = {
    cpu: document.getElementById("server_cpu").value,
    ram: document.getElementById("server_ram").value,
    disk: document.getElementById("server_disk").value,
    databases: document.getElementById("server_databases").value,
    backups: document.getElementById("server_backups").value,
    ports: document.getElementById("server_ports").value,
  };
  if (
    !data.cpu ||
    !data.ram ||
    !data.disk ||
    !data.databases ||
    !data.backups ||
    !data.ports
  )
    return Swal.fire({
      title: "Error!",
      text: `Please fillout the all of the fields!`,
      icon: "error",
      confirmButtonText: "OK",
    });
  if (
    numberCheck(data.cpu) == false ||
    numberCheck(data.ram) == false ||
    numberCheck(data.disk) == false ||
    numberCheck(data.databases) == false ||
    numberCheck(data.backups) == false ||
    numberCheck(data.ports) == false
  )
    return Swal.fire({
      title: "Error!",
      text: `Please enter valid information.`,
      icon: "error",
      confirmButtonText: "OK",
    });
  $.ajax({
    type: "PATCH",
    url: `/api/server/${server_id}`,
    data: JSON.stringify(data),
  }).done(function (response) {
    if (response.message === "success") {
      return Swal.fire({
        title: "Success!",
        text: "Editing Server was successful!",
        icon: "success",
        confirmButtonText: "OK",
      }).then(() => {
        window.location.replace("/");
      });
    } else {
      return Swal.fire({
        title: "Error!",
        text: `Editing Server was not successful! Error: ${response.message}`,
        icon: "error",
        confirmButtonText: "OK",
      }).then(() => {
        window.location.replace("/");
      });
    }
  });
});
function delete_server(id) {
  $.ajax({
    type: "DELETE",
    url: `/api/server/${id}`,
  }).done(function (response) {
    if (response.message == "success") {
      Swal.fire({
        title: "Success!",
        text: "Your Server have been deleted!",
        icon: "success",
        confirmButtonText: "OK",
      }).then(() => {
        location.reload();
      });
    } else {
      Swal.fire({
        title: "Error!",
        text: `Deleting server was not successful! Error: ${response.message}`,
        icon: "error",
        confirmButtonText: "OK",
      }).then(() => {
        location.reload();
      });
    }
  });
}
