function recaptchaSubmit(recaptchaResponse) {
  var data = {
    value: document.getElementById("value").value,
    recaptchaResponse: recaptchaResponse,
  };
  $.ajax({
    type: "POST",
    url: `/api/recaptcha/resetPass`,
    data: JSON.stringify(data),
  })
    .done(function (response) {
      doreset(response.value);
    })
    .fail(function (error) {
      return Swal.fire({
        title: "Error!",
        text: `ReCaptcha Error! Error: ${response.message}`,
        icon: "error",
        confirmButtonText: "OK",
      });
    })
    .always(function () {
      grecaptcha.reset();
    });
}
function doreset(value) {
  const values = {
    value: value,
  };
  $.ajax({
    type: "POST",
    url: `/api/password/reset/request`,
    data: JSON.stringify(values),
  }).done(function (response) {
    if (response.message === "success") {
      return Swal.fire({
        title: "Success!",
        text: "Check your email for the reset instructions!",
        icon: "success",
        confirmButtonText: "OK",
      });
    } else {
      return Swal.fire({
        title: "Error!",
        text: `${response.message}`,
        icon: "error",
        confirmButtonText: "OK",
      });
    }
  });
}
$("#resetForm").submit(async function (e) {
  e.preventDefault();
  grecaptcha.execute();
});
