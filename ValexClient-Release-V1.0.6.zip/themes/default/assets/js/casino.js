const perfecthalf = ((1 / 37) * 360) / 2;

  let currentLength = perfecthalf;

  $(".wheel img").css("transform", "rotate(" + perfecthalf + "deg)");

  $(document).ready(function () {

    $.ajax({
      type: "GET",
      url: `/api/casino`,
      data: {},
    }).done(function (response) {
      if (response.message == "success") document.getElementById("limits").innerHTML = response.limits
      else document.getElementById("limits").innerHTML = 0
    })

    $("#roll").click(function () {
      $(".wheel img").css("filter", "blur(8px)");

      spininterval = getRandomInt(0, 37) * (360 / 37) + getRandomInt(3, 4) * 360;
      currentLength += spininterval;

      numofsecs = spininterval;

      $(".wheel img").css("transform", "rotate(" + currentLength + "deg)");

      setTimeout(function () {
        $(".wheel img").css("filter", "blur(0px)");
      }, numofsecs);

      setTimeout(function () {
        $.ajax({
          type: "POST",
          url: `/api/casino`,
          data: JSON.stringify({bid: document.getElementById("bid").value}),
        }).done(function (response) {
          if (response.message === "success") {
            if (response.result == "win") {
              document.getElementById("coins").innerHTML = response.coins
              document.getElementById("payload").innerHTML = parseInt(document.getElementById("payload").innerHTML) + response.winnings
              document.getElementById("limits").innerHTML = response.limits
              alert(response.limits)
              return Swal.fire({
                title: "WON!",
                text: `You won ${response.winnings} credits.`,
                icon: "success",
                confirmButtonText: "OK",
              })
            } else {
              document.getElementById("coins").innerHTML = response.coins
              document.getElementById("payload").innerHTML = parseInt(document.getElementById("payload").innerHTML) - response.winnings
              document.getElementById("limits").innerHTML = response.limits
              return Swal.fire({
                title: "LOST!",
                text: `You lost ${response.winnings} credits.`,
                icon: "error",
                confirmButtonText: "OK",
              })
            }
          } else {
            return Swal.fire({
              title: "Error!",
              text: `${response.message}`,
              icon: "error",
              confirmButtonText: "OK",
            });
          }
        })
      }, 10000)
    });
  })

  function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }  