function numberCheck(num) {
    if (isNaN(num)) return false
    if (num % 1 !== 0) return false
    else return true
}