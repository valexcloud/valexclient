if (document.getElementById("credit_card")) {
  var cardNum = document.getElementById("credit_card");
  cardNum.onkeyup = function (e) {
    if (this.value == this.lastValue) return;
    var caretPosition = this.selectionStart;
    var sanitizedValue = this.value.replace(/[^0-9]/gi, "");
    var parts = [];

    for (var i = 0, len = sanitizedValue.length; i < len; i += 4) {
      parts.push(sanitizedValue.substring(i, i + 4));
    }

    for (var i = caretPosition - 1; i >= 0; i--) {
      var c = this.value[i];
      if (c < "0" || c > "9") {
        caretPosition--;
      }
    }
    caretPosition += Math.floor(caretPosition / 4);
    
    this.value = this.lastValue = parts.join(" ");
    this.selectionStart = this.selectionEnd = caretPosition;
  };
  $("#stripe").submit(async function (e) {
    e.preventDefault();
    const coins = document.getElementById("stripe_coins").value;
    const raw_card = document.getElementById("credit_card").value;
    const exp_year = document.getElementById("exp_year").value;
    const exp_month = document.getElementById("exp_month").value;
    const cvc = document.getElementById("cvc").value;
    const card = raw_card.replace(/\s+/g, "");
    $.ajax({
      type: "POST",
      url: `/api/buy_coins/stripe`,
      data: JSON.stringify({
        coins: Number(coins),
        credit_card: Number(card),
        exp_year: Number(exp_year),
        exp_month: Number(exp_month),
        cvc: Number(cvc),
      }),
    }).done(function (response) {
      if (response.status === "success") {
        Swal.fire({
          title: "Success!",
          text: "Your Purchase was Accepted!",
          icon: "success",
          confirmButtonText: "OK",
        }).then(() => {
          location.reload();
        });
      } else if (response.status === "declined") {
        Swal.fire({
          title: "Error!",
          text: `${response.message}`,
          icon: "error",
          confirmButtonText: "OK",
        }).then(() => {
          location.reload();
        });
      } else {
        Swal.fire({
          title: "Error!",
          text: `Error on Purchase! Error: ${response.message}`,
          icon: "error",
          confirmButtonText: "OK",
        });
      }
    });
  });
}
$("#paypal").submit(async function (e) {
  e.preventDefault();
  const coins = document.getElementById("paypal_coins").value;
  $.ajax({
    type: "POST",
    url: `/api/buy_coins/paypal`,
    data: JSON.stringify({
      coins: Number(coins),
    }),
  }).done(function (response) {
    const url = response.redirect_url;
    window.location = url;
  });
});

const url = new URL(window.location.href);
const orderID = url.searchParams.get("token");
if (orderID) {
  $.post(`/api/buy_coins/paypal/${orderID}/capture`)
    .done((response) => {
      const c_url = new URL(window.location.href);
      c_url.searchParams.delete("paymentId");
      c_url.searchParams.delete("token");
      c_url.searchParams.delete("PayerID");
      Swal.fire({
        title: "Success!",
        text: "Your Purchase was Accepted!",
        icon: "success",
        confirmButtonText: "OK",
      }).then(() => {
        window.location.replace(c_url);
      });
    })
    .fail((err) => {
      const c_url = new URL(window.location.href);
      c_url.searchParams.delete("paymentId");
      c_url.searchParams.delete("token");
      c_url.searchParams.delete("PayerID");
      if (err.responseJSON.message === "ORDER_ALREADY_CAPTURED") {
        var error = "Looks like this order has already been placed.";
      } else {
        var error = "Oops, something went wrong.";
      }
      Swal.fire({
        title: "Error!",
        text: `Payment Error! ${error}`,
        icon: "error",
        confirmButtonText: "OK",
      }).then(() => {
        window.location.replace(c_url);
      });
    });
}
