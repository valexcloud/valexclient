function base64Decode(encodedString) {
    return Buffer.from(encodedString, 'base64').toString();
  }