$("#gift").submit(async function (e) {
  e.preventDefault();
  const values = $(this).serializeObject();
  $.ajax({
    type: "POST",
    url: `/api/gift/coins`,
    data: JSON.stringify(values),
  }).done(function (response) {
    if (response.message === "success") {
      return Swal.fire({
        title: "Success!",
        text: "Gifting coins was successful!",
        icon: "success",
        confirmButtonText: "OK",
      });
    } else {
      return Swal.fire({
        title: "Error!",
        text: `${response.message}`,
        icon: "error",
        confirmButtonText: "OK",
      });
    }
  });
});
